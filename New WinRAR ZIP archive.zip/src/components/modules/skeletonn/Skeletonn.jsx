// components/Skeleton.js  
import React from 'react';  
import styles from './skeletonn.module.scss'; // Import CSS Module for styling  

const Skeleton = () => {  
  return (  
    <>
    <div className={styles.skeletonCard}>  
      <div className={styles.skeletonImage}></div>  
      <div className={styles.skel}>
      <div className={`${styles.skeletonText} ${styles.skeletonTitle}`}></div>  
      <div className={`${styles.skeletonText} ${styles.skeletonLine}`}></div>  
      <div className={`${styles.skeletonText} ${styles.skeletonLine}`}></div>  
      <div className={`${styles.skeletonText} ${styles.skeletonLine} ${styles.small}`}></div>  
      </div>
    </div>  
    </>
  );  
};  

export default Skeleton;
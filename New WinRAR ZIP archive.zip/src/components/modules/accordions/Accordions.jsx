"use client";

import React, { useState, useRef } from "react";
import styles from "./accordions.module.scss"; // Ensure you have this CSS module
import { BsChevronDown, BsTruck } from "react-icons/bs";
import { BsPersonCheckFill } from "react-icons/bs";
import Rangeslider from "@/components/modules/rangeslider/Rangeslider";
import { Checkbox } from "@heroui/react";
import Link from "next/link";

const Accordion = ({ title, content, isOpen, onToggle }) => {
  const contentRef = useRef(null);

  return (
    <>
    <div className={styles.accordion}>
      <div
        className={styles.accordionTitle}
        onClick={onToggle}
        style={{
          cursor: "pointer",
          fontSize: "15px",
          paddingInline: "20px",
          paddingBlock: "20px",
        }}
      >
        {title}
        <BsChevronDown
          style={{
            transition: "transform 0.3s",
            transform: isOpen ? "rotate(180deg)" : "rotate(0deg)",
          }}
        />
      </div>
      <div
        className={`${styles.accordionContent} ${isOpen ? styles.open : ""}`}
        ref={contentRef}
        style={{
          maxHeight: isOpen ? `${contentRef.current.scrollHeight}px` : "0",
          overflow: "hidden",
          transition: "max-height 0.3s ease",
        }}
      >
        <div
          className={styles.offCanvasContent}
          style={{
            transform: isOpen ? "translateX(0)" : "translateX(100%)",
            transition: "transform 0.3s ease",
          }}
        >
          {content}
        </div>
      </div>
    </div>
    </>
  );
};

const App = () => {
  const [openIndex, setOpenIndex] = useState(null);
  const [isToggled, setIsToggled] = useState(false); // Moved toggle state here
  const [isToggleed, setIsToggleed] = useState(false); // Moved toggle state here
  const [isToggleeed, setIsToggleeed] = useState(false); // Moved toggle state here

  const toggleAccordion = (index) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  const handleToggle = () => {
    setIsToggled((prev) => !prev);
  };
  const handleTogglee = () => {
    setIsToggleed((prev) => !prev);
  };
  const handleToggleee = () => {
    setIsToggleeed((prev) => !prev);
  };

  return (
    <>
    <div className={styles.Accordion}>
      <Accordion
        title="رنگ"
        content={
          <div className={styles.ps}>
            <Link
              href={"#"}
              style={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                gap: "5px",
              }}
            >
              <ul
                style={{
                  border: "1px solid gray",
                  borderRadius: "17px",
                  height: "55px",
                  padding: "5px",
                }}
              >
                <img
                  src="/images/blue.png"
                  style={{ height: "100%", width: "100%" }}
                />
              </ul>
              <span>آبی</span>
            </Link>
            <Link
              href={"#"}
              style={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                gap: "5px",
              }}
            >
              <ul
                style={{
                  border: "1px solid gray",
                  borderRadius: "17px",
                  height: "55px",
                  padding: "5px",
                }}
              >
                <img
                  src="/images/green.png"
                  style={{ height: "100%", width: "100%" }}
                />
              </ul>
              <span>سبز</span>
            </Link>
            <Link
              href={"#"}
              style={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                gap: "5px",
              }}
            >
              <ul
                style={{
                  border: "1px solid gray",
                  borderRadius: "17px",
                  height: "55px",
                  padding: "5px",
                }}
              >
                <img
                  src="/images/yellow.png"
                  style={{ height: "100%", width: "100%" }}
                />
              </ul>
              <span>زرد</span>
            </Link>
            <Link
              href={"#"}
              style={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                gap: "5px",
              }}
            >
              <ul
                style={{
                  border: "1px solid gray",
                  borderRadius: "17px",
                  height: "55px",
                  padding: "5px",
                }}
              >
                <img
                  src="/images/gray.png"
                  style={{ height: "100%", width: "100%" }}
                />
              </ul>
              <span>طوسی</span>
            </Link>
            <Link
              href={"#"}
              style={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                gap: "5px",
              }}
            >
              <ul
                style={{
                  border: "1px solid gray",
                  borderRadius: "17px",
                  height: "55px",
                  padding: "5px",
                }}
              >
                <img
                  src="/images/black.png"
                  style={{ height: "100%", width: "100%" }}
                />
              </ul>
              <span>مشکی</span>
            </Link>
            <Link
              href={"#"}
              style={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                gap: "5px",
              }}
            >
              <ul
                style={{
                  border: "1px solid gray",
                  borderRadius: "17px",
                  height: "55px",
                  padding: "5px",
                }}
              >
                <img
                  src="/images/white.png"
                  style={{
                    border: "1px solid gray",
                    borderRadius: "10px",
                    height: "100%",
                    width: "100%",
                  }}
                />
              </ul>
              <span>سفید</span>
            </Link>
          </div>
        }
        isOpen={openIndex === 0}
        onToggle={() => toggleAccordion(0)}
      />

      <div
        style={{
          paddingInline: "20px",
          paddingBlock: "20px",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          boxShadow: "0 11px 0 -10px rgba(192, 192, 192, 0.308)",
        }}
      >
        <span style={{ display: "flex", alignItems: "center", gap: "5px" }}>
          ارسال امروز
          <BsTruck
            style={{ fontSize: "17px", marginBottom: "3px", color: "blue" }}
          />
        </span>
        <div
          className={`${styles.toggleSwitch} ${isToggled ? styles.active : ""}`} // Add 'active' class conditionally
          onClick={handleToggle}
        >
          <div
            className={`${styles.toggleCircle} ${
              isToggled ? styles.active : ""
            }`}
          ></div>
        </div>
      </div>

      <div
        style={{
          paddingInline: "20px",
          paddingBlock: "20px",
          boxShadow: "0 11px 0 -10px rgba(192, 192, 192, 0.308)",
        }}
      >
        <div
          style={{
            display: "flex",
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "space-between",
            marginBottom: "10px",
          }}
        >
          <span style={{ display: "flex", alignItems: "center", gap: "5px" }}>
            ارسال فروشنده
            <BsPersonCheckFill style={{ color: "orange" }} />
          </span>

          <div
            className={`${styles.toggleSwitch} ${
              isToggleed ? styles.active : ""
            }`} // Add 'active' class conditionally
            onClick={handleTogglee}
          >
            <div
              className={`${styles.toggleCircle} ${
                isToggleed ? styles.active : ""
              }`}
            ></div>
          </div>
        </div>
        <span style={{ color: "gray" }}>ارسال مستقیم و سریع‌تر</span>
      </div>

      <Accordion
        title={
          <span style={{ display: "flex", alignItems: "center", gap: "5px" }}>
            محدوده قیمت
          </span>
        }
        content={
          <div className={styles.ps}>
            <Rangeslider />
          </div>
        }
        isOpen={openIndex === 1}
        onToggle={() => toggleAccordion(1)}
      />
      <div
        style={{
          paddingInline: "20px",
          paddingBlock: "20px",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          boxShadow: "0 11px 0 -10px rgba(192, 192, 192, 0.308)",
        }}
      >
        <span style={{ display: "flex", alignItems: "center", gap: "5px" }}>
          فقط کالاهای موجود
        </span>
        <div
          className={`${styles.toggleSwitch} ${
            isToggleeed ? styles.active : ""
          }`} // Add 'active' class conditionally
          onClick={handleToggleee}
        >
          <div
            className={`${styles.toggleCircle} ${
              isToggleeed ? styles.active : ""
            }`}
          ></div>
        </div>
      </div>

      <Accordion
        title={
          <span
            style={{
              display: "flex",
              alignItems: "center",
              gap: "5px",
              marginBottom: "10px",
            }}
          >
            نوع فروشنده
          </span>
        }
        content={
          <div
            className={`${styles.ps} ${styles.pss}`}
            style={{ display: "flex", flexDirection: "column" }}
          >
            <ul
              style={{
                display: "flex",
                flexDirection: "row",
                alignItems: "center",
                gap: "15px",
              }}
            >
              <div style={{ width: "20px", height: "20px" }}>
                <input type="checkbox" />
              </div>
              <span style={{ fontSize: "18px" }}>فروشنده رسمی</span>
            </ul>
            <ul
              style={{
                display: "flex",
                flexDirection: "row",
                alignItems: "center",
              }}
            >
              <div style={{ width: "20px", height: "20px" }}>
                <input type="checkbox" />
              </div>
              <span style={{ fontSize: "18px" }}>فروشنده برگزیده</span>
            </ul>
            <ul
              style={{
                display: "flex",
                flexDirection: "row",
                alignItems: "center",
              }}
            >
              <div style={{ width: "20px", height: "20px" }}>
                <input type="checkbox" />
              </div>
              <span style={{ fontSize: "18px" }}>کسب و کارهای بومی</span>
            </ul>
          </div>
        }
        isOpen={openIndex === 2}
        onToggle={() => toggleAccordion(2)}
      />
      <Accordion
        title={
          <span
            style={{
              display: "flex",
              alignItems: "center",
              gap: "5px",
              marginBottom: "10px",
            }}
          >
            شبکه های مخابراتی
          </span>
        }
        content={
          <div
            className={`${styles.ps} ${styles.pss}`}
            style={{ display: "flex", flexDirection: "column" }}
          >
            <ul
              style={{
                display: "flex",
                flexDirection: "row",
                alignItems: "center",
              }}
            >
              <div style={{ width: "20px", height: "20px" }}>
                <input type="checkbox" />
              </div>
              <span style={{ fontSize: "18px" }}>2G</span>
            </ul>
            <ul
              style={{
                display: "flex",
                flexDirection: "row",
                alignItems: "center",
              }}
            >
              <div style={{ width: "20px", height: "20px" }}>
                <input type="checkbox" />
              </div>
              <span style={{ fontSize: "18px" }}>3G</span>
            </ul>
            <ul
              style={{
                display: "flex",
                flexDirection: "row",
                alignItems: "center",
              }}
            >
              <div style={{ width: "20px", height: "20px" }}>
                <input type="checkbox" />
              </div>
              <span style={{ fontSize: "18px" }}>4G</span>
            </ul>
            <ul
              style={{
                display: "flex",
                flexDirection: "row",
                alignItems: "center",
              }}
            >
              <div style={{ width: "20px", height: "20px" }}>
                <input type="checkbox" />
              </div>
              <span style={{ fontSize: "18px" }}>5G</span>
            </ul>
          </div>
        }
        isOpen={openIndex === 3}
        onToggle={() => toggleAccordion(3)}
      />
      <Accordion
        title={
          <span
            style={{
              display: "flex",
              alignItems: "center",
              gap: "5px",
              marginBottom: "10px",
            }}
          >
            سیستم عامل
          </span>
        }
        content={
          <div
            className={`${styles.ps} ${styles.pss}`}
            style={{ display: "flex", flexDirection: "column" }}
          >
            <ul
              style={{
                display: "flex",
                flexDirection: "row",
                alignItems: "center",
              }}
            >
              <div style={{ width: "20px", height: "20px" }}>
                <input type="checkbox" />
              </div>
              <span style={{ fontSize: "18px" }}>اندروید</span>
            </ul>
            <ul
              style={{
                display: "flex",
                flexDirection: "row",
                alignItems: "center",
              }}
            >
              <div style={{ width: "20px", height: "20px" }}>
                <input type="checkbox" />
              </div>
              <span style={{ fontSize: "18px" }}>ios</span>
            </ul>
          </div>
        }
        isOpen={openIndex === 4}
        onToggle={() => toggleAccordion(4)}
      />
      <Accordion
        title={
          <span
            style={{
              display: "flex",
              alignItems: "center",
              gap: "5px",
              marginBottom: "10px",
            }}
          >
            تعداد سیم کارت
          </span>
        }
        content={
          <div
            className={`${styles.ps} ${styles.pss}`}
            style={{ display: "flex", flexDirection: "column" }}
          >
            <ul
              style={{
                display: "flex",
                flexDirection: "row",
                alignItems: "center",
              }}
            >
              <div style={{ width: "20px", height: "20px" }}>
                <input type="checkbox" />
              </div>
              <span style={{ fontSize: "18px" }}>دو عدد</span>
            </ul>
            <ul
              style={{
                display: "flex",
                flexDirection: "row",
                alignItems: "center",
              }}
            >
              <div style={{ width: "20px", height: "20px" }}>
                <input type="checkbox" />
              </div>
              <span style={{ fontSize: "18px" }}>یک عدد</span>
            </ul>
          </div>
        }
        isOpen={openIndex === 5}
        onToggle={() => toggleAccordion(5)}
      />
      <Accordion
        title={
          <span
            style={{
              display: "flex",
              alignItems: "center",
              gap: "5px",
              marginBottom: "10px",
            }}
          >
            حافظه داخلی
          </span>
        }
        content={
          <div
            className={`${styles.ps} ${styles.pss}`}
            style={{ display: "flex", flexDirection: "column" }}
          >
            <ul
              style={{
                display: "flex",
                flexDirection: "row",
                alignItems: "center",
              }}
            >
              <div style={{ width: "20px", height: "20px" }}>
                <input type="checkbox" />
              </div>
              <span style={{ fontSize: "18px" }}>۱ ترابایت</span>
            </ul>
            <ul
              style={{
                display: "flex",
                flexDirection: "row",
                alignItems: "center",
              }}
            >
              <div style={{ width: "20px", height: "20px" }}>
                <input type="checkbox" />
              </div>
              <span style={{ fontSize: "18px" }}>۱۲۸ ترابایت</span>
            </ul>
            <ul
              style={{
                display: "flex",
                flexDirection: "row",
                alignItems: "center",
              }}
            >
              <div style={{ width: "20px", height: "20px" }}>
                <input type="checkbox" />
              </div>
              <span style={{ fontSize: "18px" }}>۳۲ ترابایت</span>
            </ul>
            <ul
              style={{
                display: "flex",
                flexDirection: "row",
                alnItems: "center",
              }}
            >
              <div style={{ width: "20px", height: "20px" }}>
                <input type="checkbox" />
              </div>
              <span style={{ fontSize: "18px" }}>۲۵۶ ترابایت</span>
            </ul>
            <ul
              style={{
                display: "flex",
                flexDirection: "row",
                alnItems: "center",
              }}
            >
              <div style={{ width: "20px", height: "20px" }}>
                <input type="checkbox" />
              </div>
              <span style={{ fontSize: "18px" }}>۵۱۲ ترابایت</span>
            </ul>
            <ul
              style={{
                display: "flex",
                flexDirection: "row",
                alnItems: "center",
              }}
            >
              <div style={{ width: "20px", height: "20px" }}>
                <input type="checkbox" />
              </div>
              <span style={{ fontSize: "18px" }}>۶۴ ترابایت</span>
            </ul>
          </div>
        }
        isOpen={openIndex === 6}
        onToggle={() => toggleAccordion(6)}
      />
      <Accordion
        title={
          <span
            style={{
              display: "flex",
              alignItems: "center",
              gap: "5px",
              marginBottom: "10px",
            }}
          >
            مقدار RAM
          </span>
        }
        content={
          <div
            className={`${styles.ps} ${styles.pss}`}
            style={{ display: "flex", flexDirection: "column" }}
          >
            <ul
              style={{
                display: "flex",
                flexDirection: "row",
                alignItems: "center",
              }}
            >
              <div style={{ width: "20px", height: "20px" }}>
                <input type="checkbox" />
              </div>
              <span style={{ fontSize: "18px" }}>۱ ترابایت</span>
            </ul>
            <ul
              style={{
                display: "flex",
                flexDirection: "row",
                alignItems: "center",
              }}
            >
              <div style={{ width: "20px", height: "20px" }}>
                <input type="checkbox" />
              </div>
              <span style={{ fontSize: "18px" }}>۱۲۸ ترابایت</span>
            </ul>
            <ul
              style={{
                display: "flex",
                flexDirection: "row",
                alignItems: "center",
              }}
            >
              <div style={{ width: "20px", height: "20px" }}>
                <input type="checkbox" />
              </div>
              <span style={{ fontSize: "18px" }}>۳۲ ترابایت</span>
            </ul>
            <ul
              style={{
                display: "flex",
                flexDirection: "row",
                alnItems: "center",
              }}
            >
              <div style={{ width: "20px", height: "20px" }}>
                <input type="checkbox" />
              </div>
              <span style={{ fontSize: "18px" }}>۲۵۶ ترابایت</span>
            </ul>
            <ul
              style={{
                display: "flex",
                flexDirection: "row",
                alnItems: "center",
              }}
            >
              <div style={{ width: "20px", height: "20px" }}>
                <input type="checkbox" />
              </div>
              <span style={{ fontSize: "18px" }}>۵۱۲ ترابایت</span>
            </ul>
            <ul
              style={{
                display: "flex",
                flexDirection: "row",
                alnItems: "center",
              }}
            >
              <div style={{ width: "20px", height: "20px" }}>
                <input type="checkbox" />
              </div>
              <span style={{ fontSize: "18px" }}>۶۴ ترابایت</span>
            </ul>
          </div>
        }
        isOpen={openIndex === 7}
        onToggle={() => toggleAccordion(7)}
      />
      <Accordion
        title={
          <span
            style={{
              display: "flex",
              alignItems: "center",
              gap: "5px",
              marginBottom: "10px",
            }}
          >
            قابلیت های شارژ
          </span>
        }
        content={
          <div
            className={`${styles.ps} ${styles.pss}`}
            style={{ display: "flex", flexDirection: "column" }}
          >
            <ul
              style={{
                display: "flex",
                flexDirection: "row",
                alignItems: "center",
              }}
            >
              <div style={{ width: "20px", height: "20px" }}>
                <input type="checkbox" />
              </div>
              <span style={{ fontSize: "18px" }}>شارژ با سیم</span>
            </ul>
            <ul
              style={{
                display: "flex",
                flexDirection: "row",
                alignItems: "center",
              }}
            >
              <div style={{ width: "20px", height: "20px" }}>
                <input type="checkbox" />
              </div>
              <span style={{ fontSize: "18px" }}>شارژ بی سیم</span>
            </ul>
            <ul
              style={{
                display: "flex",
                flexDirection: "row",
                alignItems: "center",
              }}
            >
              <div style={{ width: "20px", height: "20px" }}>
                <input type="checkbox" />
              </div>
              <span style={{ fontSize: "18px" }}>شارژ معکوس</span>
            </ul>
          </div>
        }
        isOpen={openIndex === 8}
        onToggle={() => toggleAccordion(8)}
      />
    </div>
    </>
  );
};

export default App;

"use client";

import React, { useState, useRef } from "react";
import styles from "./accordion.module.scss"; // Ensure you have this CSS module
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faChevronDown } from "@fortawesome/free-solid-svg-icons";
import Link from "next/link";
import Image from "next/image";
import { BsChevronDown } from "react-icons/bs";

const Accordion = ({ title, content }) => {
  const [isOpen, setIsOpen] = useState(false);
  const contentRef = useRef(null);

  const toggleAccordion = () => {
    setIsOpen(!isOpen);
  };

  return (
    <>
    <div className={styles.accordion}>
      <div
        className={styles.accordionTitle}
        onClick={toggleAccordion}
        style={{
          cursor: "pointer",
          fontSize: "1.2em",
          padding: "10px",
          background: "#f1f1f1",
        }}
      >
        <BsChevronDown
          style={{
            transition: "transform 0.3s",
            transform: isOpen ? "rotate(180deg)" : "rotate(0deg)",
          }}
        />
        {title}
      </div>
      <div
        className={`${styles.accordionContent} ${isOpen ? styles.open : ""}`}
        ref={contentRef}
        style={{
          maxHeight: isOpen ? `${contentRef.current.scrollHeight}px` : "0",
          overflow: "hidden",
          transition: "max-height 0.3s ease",
        }}
      >
        <div
          className={styles.offCanvasContent}
          style={{
            transform: isOpen ? "translateX(0)" : "translateX(100%)",
            transition: "transform 0.3s ease",
          }}
        >
          {content}
        </div>
      </div>
    </div>
    </>
  );
};

const App = () => {
  return (
    <>
    <div className={styles.Accordionn} style={{ margin: "10px" }}>
      <Accordion
        title="اینجا"
        content={
          <>
            {" "}
            <p
              style={{
                display: "flex",
                flexDirection: "column",
                gap: "10px",
                padding: "10px",
              }}
              className={styles.ps}
            >
              <a href="">شرایط و قوانین</a> <a href="">تماس با ما</a>{" "}
              <a href="">احذ مجوز</a> <a href="">همکاری</a>
            </p>{" "}
          </>
        }
      />
      <Accordion
        title="میز خدمت اینجا"
        content={
          <>
            {" "}
            <p
              style={{
                display: "flex",
                flexDirection: "column",
                gap: "10px",
                padding: "10px",
              }}
              className={styles.ps}
            >
              <a href="">شرایط استفاده</a> <a href="">پاسخ به پرسش</a>{" "}
              <a href="">حریم خصوصی</a> <a href="">گزارش باگ</a>
            </p>{" "}
          </>
        }
      />
      <Accordion
        title="اینجا در همه جا"
        content={
          <div style={{display:"flex",alignItems:"center",flexDirection:'column',justifyContent:"center",gap:"20px",paddingBlock:"20px"}}>
            <Link href={"/"}  style={{  width:"50%",height:"10dvh" }}>
              <Image
                style={{  width:"100%",height:"100%" }}
                src="/images/play stor.webp"
                alt="salam"
                width={900}
                height={900}
              />
            </Link>

            <Link href={"/"}  style={{  width:"50%",height:"10dvh" }}>
              <Image
                style={{  width:"100%",height:"100%"  }}
                src="/images/Bazar.png"
                alt="salam"
                width={900}
                height={900}
              />
            </Link>

            <Link href={"/"}  style={{  width:"52%",height:"10dvh" }}>
              <Image
               style={{  width:"100%",height:"110%"  }}
                src="/images/miket.png"
                alt="salam"
                width={900}
                height={900}
              />
            </Link>
          </div>
        }
      />
    </div>
    </>
  );
};

export default App;

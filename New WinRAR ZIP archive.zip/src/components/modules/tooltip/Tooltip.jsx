"use client"
import { BsSuitHeart } from "react-icons/bs";
import { BsShareFill } from "react-icons/bs";
import { BsBell } from "react-icons/bs";
import { BsGraphUp } from "react-icons/bs";
import { BsSquareHalf } from "react-icons/bs";
import { BsListUl } from "react-icons/bs";
import React, { useState } from 'react';

const Tooltip = ({ children, text }) => {
  const [visible, setVisible] = useState(false);

  const tooltipStyle = {
    position: 'absolute',
    bottom: '30%',
    backgroundColor: 'rgba(0, 0, 0, 0.75)',
    color: 'white',
    padding: '5px',
    borderRadius: '5px',
    whiteSpace: 'nowrap',
    zIndex: 10,
    opacity: visible ? 1 : 0,
    right: '30px',
    pointerEvents: 'none',  // Ensures the tooltip itself doesn't interfere with mouse events
    transition: 'opacity 0.3s'
  };

  const containerStyle = {
    position: 'relative',
    display: 'inline-block',
  };

  const handleMouseEnter = () => setVisible(true);
  const handleMouseLeave = () => setVisible(false);

  return (
    <div style={containerStyle}>
      <div onMouseEnter={handleMouseEnter} onMouseLeave={handleMouseLeave}>
        {children}
      </div>
      <div style={tooltipStyle}>{text}</div>
    </div>
  );
};

const HomePage = () => {
  return (
    <>
    <div style={{ width: '10%', display: 'flex', flexDirection: 'column', position: 'absolute', top: '0', right: '0', gap: '10px'}}>
      <Tooltip text="افزودن به علاقه مندی ها">
        <button style={{ fontSize: '20px' }}><BsSuitHeart /></button>
      </Tooltip>
      <Tooltip text="به اشتراک گذاری کالا">
        <button style={{ fontSize: '20px' }}><BsShareFill /></button>
      </Tooltip>
      <Tooltip text="اطلاع رسانی">
        <button style={{ fontSize: '20px' }}><BsBell /></button>
      </Tooltip>
      <Tooltip text="نموار قیمت">
        <button style={{ fontSize: '20px' }}><BsGraphUp /></button>
      </Tooltip>
      <Tooltip text="مقایسه کالا">
        <button style={{ fontSize: '20px' }}><BsSquareHalf /></button>
      </Tooltip>
      <Tooltip text="افزودن به لیست">
        <button style={{ fontSize: '20px' }}><BsListUl /></button>
      </Tooltip>
    </div>
    </>
  );
};

export default HomePage;

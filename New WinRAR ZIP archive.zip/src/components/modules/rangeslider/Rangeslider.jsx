import React, { useState } from 'react';  
import ReactSlider from 'react-slider';  
import styles from './rangeslider.module.scss';  

const RangeSlider = () => {  
    const [range, setRange] = useState([350, 900]);  

    const handleSliderChange = (newRange) => {  
        setRange(newRange);  
    };  

    // Calculate track left position and width dynamically  
    const trackStyle = {  
        left: `${((range[0] - 350) / (900 - 350)) * 100}%`, // Calculate left position based on min value  
        width: `${((range[1] - range[0]) / (900 - 350)) * 100}%`, // Calculate width based on the selected range  
    };  

    return (  
        <>
        <div className="slider-container" style={{ width: '200px' }}>  
            <label htmlFor="price-range" className="mb-2 text-lg font-semibold">محدوده قیمت</label>  
            <div className="relative w-full">  
                <ReactSlider  
                    className={styles.slider}  
                    thumbClassName="thumb"  
                    trackClassName="track"  
                    min={350}  
                    max={900}  
                    value={range}  
                    onChange={handleSliderChange}  
                    renderThumb={(props) => {  
                        const { key, ...otherProps } = props;  // Destructure to separate the key  
                        return <div key={key} {...otherProps} className={styles.thumb} />;  
                    }}  
                />  
                <div  
                    className="track"  
                    style={{  
                        ...trackStyle,  
                        backgroundColor: '#007bff', // Dynamic blue color for selected range  
                        position: 'absolute',  
                        top: '50%',  
                        height: '18px', // Track height  
                        transform: 'translateY(-50%)',  
                        borderRadius: '3px',  
                    }}  
                />  
            </div>  
            <div className="price-labels mt-2 flex justify-between">  
                <span>{`${range[1]}.00 تومان`}</span>  
                <span>{`${range[0]}.00 تومان`}</span>  
            </div>  
        </div>  
        </>
    );  
};  

export default RangeSlider;
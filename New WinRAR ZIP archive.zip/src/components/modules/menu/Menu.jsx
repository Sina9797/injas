"use client"
import { useState, useEffect } from 'react';  
import Link from 'next/link';  
import styles from './menu.module.scss'; // Import the SCSS module  
import { BsPersonFill } from "react-icons/bs";  
import { TbShoppingCartFilled } from "react-icons/tb";  
import { TbCategoryFilled } from "react-icons/tb";  
import { BsHouseFill } from "react-icons/bs";  

export default function Home() {  
    const [activePath, setActivePath] = useState('');  

    const menuItems = [  
        { id: 1, svg: <BsPersonFill />, label: 'ورود', path: '/vorud' },  
        { id: 2, svg: <TbShoppingCartFilled />, label: 'سبد خرید', path: '/sabad' },  
        { id: 3, svg: <TbCategoryFilled />, label: 'دسته بندی', path: '/dastebandi' },  
        { id: 4, svg: <BsHouseFill />, label: 'خانه', path: '/' },  
    ];  

    // Set the initial active path based on current pathname  
    useEffect(() => {  
        setActivePath(window.location.pathname);  
    }, []);  

    // Update the active path when a link is clicked  
    const handleLinkClick = (path) => {  
        setActivePath(path);  
    };  

    return (  
        <>
        <div>  
            <div className={styles.menuBar}>  
                {menuItems.map((item) => (  
                    <Link href={item.path} key={item.id} style={{ textDecoration: "none" }} onClick={() => handleLinkClick(item.path)}>  
                        <div  
                            className={`${styles.menuItem} ${activePath === item.path ? styles.active : ''}`} // Apply active class based on current path  
                        >  
                            {item.svg}  
                            <span>{item.label}</span>  
                        </div>  
                    </Link>  
                ))}  
            </div>  
        </div>  
        </>
    );  
}
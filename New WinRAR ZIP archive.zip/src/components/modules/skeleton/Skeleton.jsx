// components/SkeletonLoader.js
import Skeleton from "react-loading-skeleton";
import "react-loading-skeleton/dist/skeleton.css";

const SkeletonLoader = () => (
  <>
  <Skeleton
    style={{
      width: "100%",
      height: "100%",
      borderRadius: "15px",
      position: "absolute",
      display: "block",
      inset: "0",
      zIndex: "9",
    }}
  />
  </>
);

export default SkeletonLoader;

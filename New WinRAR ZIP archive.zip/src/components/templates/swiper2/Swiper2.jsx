"use client";  

import styles from "./swiper2.module.scss";  
import { Swiper, SwiperSlide } from "swiper/react";  
import Link from "next/link";  
import Image from "next/image";  
import Skeleton from "../../modules/skeleton/Skeleton";  
import React, { useState } from "react";  
import db from "../../../../data/db.json";  

function Swiper2() {  
  const [isLoading, setIsLoading] = useState(true);  

  const handleImageLoad = () => {  
    setIsLoading(false);  
  };  

  return (  
    <>
    <div className={styles.HH}>  
      {/* First Swiper */}  
      <Swiper  
        slidesPerView={7}  
        spaceBetween={30}  
        className={`${styles.mySwiper} d-none d-xxl-flex`}  
      >  
        {db.swiperr.map(item => (  
          <SwiperSlide key={item.id || item.title} className={styles.SWW}>  
            <Link className={styles.SW} href="#">  
              <div  
                style={{  
                  display: "flex",  
                  flexDirection: "column",  
                  alignItems: "center",  
                  paddingBottom: "20px",  
                }}  
              >  
                <Image  
                  style={{ width: "40px", height: "40px" }}  
                  src="/images/bluetick.png"  
                  width={40}  
                  height={40}  
                  alt="Blue tick icon"  
                />  
                <b>{item.title}</b>  
                <span style={{ color: "gray" }}>{item.description}</span>  
              </div>  
              <Image  
                src={item.img}  
                width={900}  
                height={900}  
                alt={`Image for ${item.title}`}  
                onLoad={handleImageLoad}  
              />  
              {isLoading && <Skeleton />}  
            </Link>  
          </SwiperSlide>  
        ))}  
      </Swiper>  

      {/* Second Swiper */}  
      <Swiper  
        slidesPerView={4}  
        centeredSlides={false}  
        spaceBetween={15}  
        grabCursor={true}  
        className={`${styles.mySwiper} d-none d-md-flex d-xxl-none`}  
      >  
        {db.swiperr.map(item => (  
          <SwiperSlide key={item.id || item.title} className={styles.SWW} style={{ width: "22%" }}>  
            <Link className={styles.SW} href="#">  
              <div  
                style={{  
                  display: "flex",  
                  flexDirection: "column",  
                  alignItems: "center",  
                  paddingBottom: "20px",  
                }}  
              >  
                <Image  
                  style={{ width: "40px", height: "40px" }}  
                  src="/images/bluetick.png"  
                  width={40}  
                  height={40}  
                  alt="Blue tick icon"  
                />  
                <b>{item.title}</b>  
                <span style={{ color: "gray" }}>{item.description}</span>  
              </div>  
              <Image  
                src={item.img}  
                width={900}  
                height={900}  
                alt={`Image for ${item.title}`}  
                onLoad={handleImageLoad}  
              />  
              {isLoading && <Skeleton />}  
            </Link>  
          </SwiperSlide>  
        ))}  
      </Swiper>  

      {/* Third Swiper */}  
      <Swiper  
        slidesPerView={2}  
        centeredSlides={false}  
        spaceBetween={10}  
        grabCursor={true}  
        className={`${styles.mySwiper} d-md-none`}  
      >  
        {db.swiperr.map(item => (  
          <SwiperSlide key={item.id || item.title} className={styles.SWW} style={{ width: "45%" }}>  
            <Link className={styles.SW} href="#">  
              <div  
                style={{  
                  display: "flex",  
                  flexDirection: "column",  
                  alignItems: "center",  
                  paddingBottom: "20px",  
                }}  
              >  
                <Image  
                  style={{ width: "40px", height: "40px" }}  
                  src="/images/bluetick.png"  
                  width={40}  
                  height={40}  
                  alt="Blue tick icon"  
                />  
                <b>{item.title}</b>  
                <span style={{ color: "gray" }}>{item.description}</span>  
              </div>  
              <Image  
                src={item.img}  
                width={900}  
                height={900}  
                alt={`Image for ${item.title}`}  
                onLoad={handleImageLoad}  
              />  
              {isLoading && <Skeleton />}  
            </Link>  
          </SwiperSlide>  
        ))}  
      </Swiper>  
    </div>  
    </>
  );  
}  

export default Swiper2;
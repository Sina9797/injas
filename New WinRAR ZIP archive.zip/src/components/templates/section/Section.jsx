import React from "react";
import Link from "next/link";

const Swction = () => {
  return (
    <>
      <div className="ZZ">
        <span>
          <span style={{ color: "red" }}>اینجا</span> شبکه‌ای برای فروش است که
          از سال ۱۳۹۳ شمسی با هدف ارائه و مقایسه شفاف قیمت‌ها راه‌اندازی شد.{" "}
          <span>
            سال ۱۳۹۵ شرکت فن‌ آوران پیشرو دیجیتال برای اداره‌ی کارهای این سرویس
            ثبت شد و در حال حاضر همه‌ی حقوق{" "}
            <span style={{ color: "red" }}>اینجا</span> متعلق به شرکت «فن‌آوران
            نوین» است
          </span>
        </span>
        <span>
          .
          <span>
            مهم‌ترین فعالیت این شرکت توسعه‌ی موتور جستجوی خرید{" "}
            <span style={{ color: "red" }}>اینجا</span> است
          </span>{" "}
          <span>
            این موتور جستجو بالغ بر میلیون‌ها محصول از بیش از ۱۴ هزار فروشگاه
            معتبر اینترنتی ایرانی را جمع‌اوری کرده است تا به کاربران کمک کند در
            کمترین زمان بهترین قیمت‌ها را پیدا کنند
          </span>
        </span>
        <span>
          .
          <span>
            همچنین <span style={{ color: "red" }}>اینجا</span> به فروشگاه‌های
            اینترنتی معتبر کمک می‌کند تا بدون نیاز به دانش فنی بتوانند به
            گستره‌ی بزرگی از کاربران اینترنتی دسترسی پیدا کنند.
          </span>
        </span>
      </div>

      <div className="A" d-none="true" d-lg-flex="true">
        <div className="J">
          <span>
            آدرس : تهران - زعفرانیه - خیابان شهید فلاحی - تقاطع خیابان مقدس
            اردبیلی - پلاک ۲۰۹
          </span>
          <div className="L" d-none="true" d-xl-flex="true"></div>
          <span>۰۲۱-۹۹۹۹۹۹۱۷۰ : تلفن پشتیبانی</span>
        </div>
        <Link className="K" href="#">
          www.inja.com
        </Link>
      </div>
    </>
  );
};

export default Swction;

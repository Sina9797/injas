import React from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import Image from "next/image";

// Import Swiper styles
import "swiper/css";
import "swiper/css/free-mode";
import "swiper/css/navigation";
import "swiper/css/pagination"; // Import pagination styles

import styles from "./swiper11.module.scss";

// Import required modules
import { Autoplay, FreeMode, Navigation, Pagination } from "swiper/modules";

export default function App() {
  const images = [
    { id: 1, picture: "/images/1.webp" },
    { id: 2, picture: "/images/4.webp" },
    { id: 3, picture: "/images/3.webp" },
    { id: 4, picture: "/images/4.webp" },
    { id: 5, picture: "/images/5.webp" },
    { id: 6, picture: "/images/6.webp" },
  ];

  return (
    <>
    <div className={`${styles.by} d-none d-sm-flex d-lg-none`}>
      <Swiper
        loop={true}
        spaceBetween={10}
        autoplay={{
          delay: 3000,
          disableOnInteraction: false,
        }}
        pagination={{
          clickable: true,
        }}
        modules={[FreeMode, Navigation, Pagination, Autoplay]}
        className={styles.mySwiper2}
      >
        {images.map((item) => (
          <SwiperSlide key={item.id}>
            <Image
              width={1500}
              height={1500}
              src={item.picture}
              alt={item.id}
              key={item.id}
            />
          </SwiperSlide>
        ))}
      </Swiper>
    </div>
    </>
  );
}

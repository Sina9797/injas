"use client"; // Ensure this component is a client component

import React from "react";
import { useState } from "react";
import Link from "next/link";
import styles from "./header.module.scss"; // Import the styles from header.module.scss
import Image from "next/image";
import { BsBoxArrowInRight } from "react-icons/bs";
import Menubar from "@/components/templates/menubar/Menubar";

function Header() {
  const [activeIndex, setActiveIndex] = useState(0);

  const menuItems = [
    { id: 1, label: "بازارچه اینجا", path: "/" }, // User SVG
    { id: 2, label: "همکاران اینجا", path: "/hamkar" }, // Cart SVG
    { id: 3, label: "جمعه اینجا", path: "/jome" }, // Grid SVG
    { id: 4, label: "تخفیف اینجا", path: "/takhfif" }, // Home SVG
    { id: 5, label: "فروشنده اینجا", path: "/forushande" }, // Home SVG
  ];
  return (
    <>
      <div className={`${styles.BB} shadow d-none d-lg-flex`}>
        <div className={styles.AAA}>
          <span className={styles.FFF}>اینجا</span>
          <span className={styles.Bar}>شبکه ای برای فروش</span>
        </div>
        <div className={styles.BBB}>
          {menuItems.map((item, index) => (
            <Link
              href={item.path}
              key={item.id}
              style={{ textDecoration: "none" }}
            >
              <div
                className={`${styles.menuItem} ${
                  activeIndex === index ? styles.active : ""
                }`} // Use SCSS styles
                onClick={() => setActiveIndex(index)}
              >
                <span>
                 {item.label}
                </span>
              </div>
            </Link>
          ))}
        </div>
        <div className={styles.EEE}>
          <Link className={styles.CCC} href="/vorud">
            <span className={styles.ABA}>
            <BsBoxArrowInRight style={{fontSize:"20px"}} />
              <span>ورود</span>
            </span>
            <span
              style={{
                borderLeft: "1px solid black",
                paddingLeft: "20px",
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                height: "70%",
              }}
            >
              <span>نام</span> ثبت
            </span>
          </Link>
          <Link className={styles.DDD} href="/sabad">
            <Image
              src="/images/bag.png"
              alt="Shopping Cart"
              width={900}
              height={900}
            />{" "}
            {/* Ensure path is correct */}
            <span
              className={styles.BAB}
              style={{ display: "flex", flexDirection: "row-reverse" }}
            >
              <span>۸۸۵,۵۰۰
              </span>
              <sub style={{ display: "flex", alignItems: "center" }}>تومان</sub>
            </span>
          </Link>
        </div>
      </div>
      <div className={styles.BBBB}>
        <Image
          src="/images/2.gif"
          alt="Mobile Header"
          width={900}
          height={900}
          key={""}
        />
        {/* Ensure path is correct */}
      </div>
      <Menubar/>
    </>
  );
}

export default Header;

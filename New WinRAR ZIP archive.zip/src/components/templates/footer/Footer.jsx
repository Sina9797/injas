import React from "react";
import styles from "./footer.module.scss"; // Ensure you create this CSS module
import Menu from "@/components/modules/menu/Menu";
import Accordion from "@/components/modules/accordion/Accordion";
import Link from "next/link"; // Use Next.js Link for navigation
import Image from "next/image";

const Footer = () => {
  const B = [
    { id: 1, title: "قوانین و شرایط" },
    { id: 2, title: "تماس با ما" },
    { id: 3, title: "اخذ مجوز" },
    { id: 4, title: "همکاری" },
  ];
  const A = [
    { id: 1, title: "شرایط استفاده" },
    { id: 2, title: "پاسح به پرسش" },
    { id: 3, title: "حریم خصوصی" },
    { id: 4, title: "کزارش باگ" },
  ];

  return (
    <>
      <div className={styles.B}>
        <div className={styles.C}>
          <Link href="/" className={styles.D}>
            <Image src="/images/B.png" alt="Logo B" width={900} height={900} />
          </Link>
          <Link href="/" className={styles.E}>
            <Image src="/images/C.png" alt="Logo C" width={900} height={900} />
          </Link>
        </div>
        <div className={styles.F}>
          <span
            style={{
              paddingRight: "5px",
              fontSize: "18px",
              marginBottom: "3%",
            }}
          >
            <b>اینجا در همه جا</b>
          </span>
          <div>
            <Link href="/play-store">
              <Image
                style={{ paddingInline: "5px", marginBottom: "3%" }}
                src="/images/play stor.webp"
                alt="Play Store"
                width={900}
                height={900}
              />
            </Link>
          </div>
          <div>
            <Link href="/bazar">
              <Image
                style={{ paddingInline: "5px", marginBottom: "0.8%" }}
                src="/images/Bazar.png"
                alt="Bazar"
                width={900}
                height={900}
              />
            </Link>
          </div>
          <div>
            <Link href="/miket">
              <Image
                src="/images/miket.png"
                alt="Miket"
                width={900}
                height={900}
              />
            </Link>
          </div>
        </div>
        <div className={styles.G}>
          <span className={styles.O}>
            <b>میز خدمت اینجا</b>
          </span>
          {A.map((item) => (
            <Link key={item.id} href={"/"} className={styles.Hs}>
              {item.title}
            </Link>
          ))}
        </div>
        <div className={styles.H}>
          <span>
            <b>اینجا</b>
          </span>
          {B.map((item) => (
            <Link key={item.id} href={"/"} className={styles.Hs}>
              {item.title}
            </Link>
          ))}
        </div>
      </div>

      <Accordion className={styles.Accordion} />
      <Menu />
    </>
  );
};

export default Footer;

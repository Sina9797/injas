"use client";  
import { useState } from "react";  
import Card2 from "@/components/templates/card2/Card2";  
import Card3 from "@/components/templates/card3/Card3";  
import Card4 from "@/components/templates/card4/Card4";  
import { color } from "framer-motion";

// Styles can be defined inline or using a CSS-in-JS approach  
const styles = {  
  container: {  
    textAlign: "center",  
    height: "max-content",  
    marginLeft: "1%",  
    marginRight: "1%",  
    backgroundColor: "rgb(151, 46, 116)",  
    paddingBlock: "20px",  
    borderRadius: "20px",  
  },  
  buttonContainer: {  
    margin: "20px 0",  
  },  
  button: {  
    padding: "5px ",  
    margin: "0 5px",  
    cursor: "pointer",  
    borderRadius: "5px",  
    color: "white",  
  },  
  activeButton: {  
    color:"orange",
   
  },  
};  

const slides = [  
  { id: 1, content: <Card2 /> },  
  { id: 2, content: <Card3 /> },  
  { id: 3, content: <Card4 /> },  
];  

export default function Home() {  
  const [currentSlide, setCurrentSlide] = useState(2); // Start with the first slide  

  const handleButtonClick = (index) => {  
    setCurrentSlide(index);  
  };  

  return (  
    <>
    <div style={styles.container}>  
      <div style={styles.buttonContainer}>  
        <button  
          style={{  
            ...styles.button,  
            ...(currentSlide === 0 ? styles.activeButton : {}),  
          }}  
          onClick={() => handleButtonClick(0)}  
        >  
          پرفروش ترین ها  
        </button> 
        <span style={{color:'white'}}>/</span> 
        <button  
          style={{  
            ...styles.button,  
            ...(currentSlide === 1 ? styles.activeButton : {}),  
          }}  
          onClick={() => handleButtonClick(1)}  
        >  
          جدیدترین ها  
        </button>  
        <span style={{color:'white'}}>/</span> 
        <button  
          style={{  
            ...styles.button,  
            ...(currentSlide === 2 ? styles.activeButton : {}),  
          }}  
          onClick={() => handleButtonClick(2)}  
        >  
          تخفیف های ویژه  
        </button>  
      </div>  
      <div style={styles.slide}>  
        {slides[currentSlide].content} {/* Render the current slide content */}  
      </div>  
    </div>  
    </>
  );  
}
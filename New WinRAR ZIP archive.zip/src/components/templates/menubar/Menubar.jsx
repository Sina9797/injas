"use client";
import styles from "./menubar.module.scss";
import Link from "next/link";
import {
  BsSearch,
  BsChevronLeft,
  BsGeoAlt,
  BsChevronDown,
} from "react-icons/bs";
import React, { useState } from "react";
import db from "../../../../data/db.json";
import { useRouter } from "next/navigation"; // Import useRouter

function Menubar() {
  const [activeSlide, setActiveSlide] = useState(0);
  const [searchQuery, setSearchQuery] = useState("");
  const router = useRouter(); // Initialize router

  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value);
  };

  const handleSearchSubmit = () => {
    if (searchQuery.trim()) {
      router.push(`/shop?query=${searchQuery}`); // Navigate to shop page with query
    }
  };

  return (
    <>
    <div
      style={{
        position: "sticky",
        top: "0px",
        zIndex: "99999",
        backgroundColor: "white",
        paddingBlock: "10px",
        background: "rgb(250, 250, 250)",
      }}
    >
      <div className={styles.AA}>
        <button
          className={styles.DD}
          onMouseEnter={() => setActiveSlide(0)}
          onMouseLeave={() => setActiveSlide(null)}
          aria-label="Open product menu"
        >
          <span>
            <BsChevronDown className={styles.VG} />
            محصولات
          </span>

          <div className={styles.DAD}>
            <div style={{ direction: "rtl" }}>
              <div className={styles.megas}>
                <div className={styles.headers}>
                  {db.slides.map((slide, index) => (
                    <div
                      key={index}
                      onMouseOver={() => setActiveSlide(index)}
                      style={{
                        backgroundColor:
                          activeSlide === index ? "white" : "transparent",
                        color: activeSlide === index ? "red" : "black",
                        border: "none",
                        width: "100%",
                        paddingInline: "2.4dvh",
                      }}
                      className={`${styles.btn} ${
                        activeSlide === index ? "active" : ""
                      }`}
                    >
                      <span style={{ textDecoration: "none" }}>
                        {slide.title}
                      </span>
                    </div>
                  ))}
                </div>
                <div className={styles.contents}>
                  <Link
                    href={`/shop?logoo=${db.slides[activeSlide]?.title}`}
                    style={{
                      fontSize: "12px",
                      display: "flex",
                      gap: "5px",
                      alignItems: "center",
                      color: "rgb(27, 170, 189)",
                      textDecoration: "none",
                    }}
                  >
                    همه محصولات {db.slides[activeSlide]?.title}
                    <BsSearch style={{ fontSize: "12px" }} />
                  </Link>
                  <ul>
                    {db.slides[activeSlide]?.items.map((item, index) => (
                      <li key={index}>
                        <span
                          style={{
                            display: "flex",
                            alignItems: "center",
                            gap: "5px",
                          }}
                        >
                          <b style={{ color: "red" }}>|</b> {item.name}
                          <BsChevronLeft style={{ fontSize: "12px" }} />
                        </span>
                        <ul
                          style={{
                            display: "flex",
                            flexDirection: "column",
                            gap: "0",
                            color: "gray",
                          }}
                        >
                          {item.details.map((detail, detailIndex) => (
                            <li key={detailIndex}>
                              <Link href={`/shop?logo=${detail}`}>
                                {detail}
                              </Link>
                            </li>
                          ))}
                        </ul>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </button>

        <div className={styles.CC}>
          <div className={`${styles.Qq} search-container`}>
            <input
              type="text"
              placeholder="جستجو در اینجا"
              value={searchQuery}
              onChange={handleSearchChange}
              onKeyDown={(e) => e.key === "Enter" && handleSearchSubmit()} // Handle Enter key
            />
            <BsSearch />
          </div>

          <Link className={styles.R} href="#">
            <span>
              <BsChevronDown />
              لبنیات
            </span>
          </Link>
          <Link className={styles.S} href="#">
            <span>
              تهران
              <BsGeoAlt style={{ fontSize: "17px" }} />
            </span>
          </Link>
        </div>
      </div>
    </div>
    </>
  );
}

export default Menubar;

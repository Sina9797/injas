"use client";  
import styles from "./pushak.module.scss";  
import Link from "next/link";  
import React, { useEffect, useState } from "react";  
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";  
import { faChevronLeft } from "@fortawesome/free-solid-svg-icons";  
import Image from "next/image";  
import Skeleton from "@/components/modules/skeleton/Skeleton";  
import db from "../../../../data/db.json";  

function Pushak() {  
  const [currentSlide, setCurrentSlide] = useState(1);  
  const [loadingImages, setLoadingImages] = useState(true);  

  const changeSlide = (slideNumber) => {  
    setCurrentSlide(slideNumber);  
  };  

  const getButtonStyle = (slideNumber) => ({  
    fontWeight: currentSlide === slideNumber ? "bold" : "normal",  
    fontSize: currentSlide === slideNumber ? "17px" : "14px",  
  });  

  const renderImages = (images) => (  
    <div className={styles.ER}>  
   {images.map((item, index) => (  
  <Link className={styles.Er} key={`${item.id || item._id}-${index}`} href="#">  
    {loadingImages && <Skeleton />}  
    <Image  
      src={item.picture}  
      alt={item.alt || ""}  
      width={300}  
      height={300}  
      onLoad={() => setLoadingImages(false)}  
    />  
  </Link>  
))} 
    </div>  
  );  

  return (  
    <>
    <div className={styles.NN}>  
      <div className={styles.OO}>  
        <div className={`${styles.QW} d-none d-sm-flex`}>  
        {db.logo.map((logo, index) => (  
  <Link className={styles.Qq} key={`${logo._id}-${index}`} href="#">  
    {loadingImages && <Skeleton />}  
    <Image  
      src={logo.picture}  
      alt="Logo"  
      width={900}  
      height={900}  
      onLoad={() => setLoadingImages(false)}  
    />  
  </Link>  
))}
        </div>  

        <div  
          style={{  
            display: "flex",  
            flexDirection: "row-reverse",  
            marginRight: "10px",  
            color: "white",  
            gap: "5px",  
            fontSize: "13px",  
          }}  
          className="d-sm-none"  
        >  
          {[1, 2, 3, 4].map((num) => (  
            <React.Fragment key={num}>  
              <button onClick={() => changeSlide(num)} style={getButtonStyle(num)}>  
                {num === 1 ? "پوشاک و کفش" : num === 2 ? "لباس مردانه" : num === 3 ? "لباس زنانه" : "لباس بچگانه"}  
              </button>  
              <span>/</span>  
            </React.Fragment>  
          ))}  
        </div>  

        <header>  
          <div className={`${styles.JOJO} d-none d-sm-flex`}>  
            {[1, 2, 3, 4].map((num) => (  
              <React.Fragment key={num}>  
                <button onClick={() => changeSlide(num)} style={getButtonStyle(num)}>  
                  {num === 1 ? "پوشاک و کفش" : num === 2 ? "لباس مردانه" : num === 3 ? "لباس زنانه" : "لباس بچگانه"}  
                </button>  
                <span>/</span>  
              </React.Fragment>  
            ))}  
          </div>  
          <Link  
            style={{  
              color: "white",  
              display: "flex",  
              alignItems: "center",  
              gap: "10px",  
              textDecoration: "none",  
            }}  
            className="d-none d-sm-flex"  
            href="#"  
          >  
            <span>  
              <b>  
                <FontAwesomeIcon icon={faChevronLeft} />  
              </b>  
            </span>  
            <span>  
              <b>محصولات بیشتر</b>  
            </span>  
          </Link>  
        </header>  

        {currentSlide === 1 && renderImages(db.pushak)}  
        {currentSlide === 2 && renderImages(db.pushakk)}  
        {currentSlide === 3 && renderImages(db.pushak)}  
        {currentSlide === 4 && renderImages(db.pushakk)}  

        <Link  
          style={{  
            color: "white",  
            display: "flex",  
            alignItems: "center",  
            gap: "10px",  
            textDecoration: "none",  
          }}  
          className="d-sm-none"  
          href="#"  
        >  
          <span>  
            <b>  
              <FontAwesomeIcon icon={faChevronLeft} />  
            </b>  
          </span>  
          <span>  
            <b>محصولات بیشتر</b>  
          </span>  
        </Link>  
      </div>  

      <div className={styles.PP}>  
        {["7.webp", "8.webp", "9.webp", "10.webp"].map((img) => (  
          <Link className={styles.QQ} key={img} href="#">  
            {loadingImages && <Skeleton />}  
            <Image  
              src={`/images/${img}`}  
              width={900}  
              height={900}  
              alt="..."  
              onLoad={() => setLoadingImages(false)}  
            />  
          </Link>  
        ))}  
      </div>  
    </div>  
    </>
  );  
}  

export default Pushak;
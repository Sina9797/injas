"use client";

import Swiper1 from "@/components/templates/swiper1/Swiper1";
import Swiper11 from "@/components/templates/swiper11/Swiper11";
import Swiper111 from "@/components/templates/swiper111/Swiper111";
import Swiper2 from "@/components/templates/swiper2/Swiper2";
import Skeleton from "@/components/modules/skeleton/Skeleton";
import Menubar from "@/components/templates/menubar/Menubar";
import Card from "@/components/templates/card/Card";
import { useState } from "react";
import Pushak from "@/components/templates/pushak/Pushak";
import Section from "@/components/templates/section/Section";
import Link from "next/link";
import Image from "next/image";
import db from "../../../../data/db.json";
import Slids from "@/components/templates/slids/Slids";
import { BsChevronLeft } from "react-icons/bs";

function HomeComponent() {
  const [isLoading, setIsLoading] = useState(true);

  return (
    <>
    
      <Swiper1 />
      <Swiper11 />
      <Swiper111 />

      <div id="GAG">
        <span>
          <b>محبوب ترین ها در اینجا</b>
        </span>
      </div>

      <Swiper2 />

      <div className="JJ">
        <span>
          <b>پیشنهادات ویژه امروز</b>
        </span>
      </div>

      <Card />

      <div className="MM" mt-4="true">
        <div className="W">
          <span>
            وسایل لوازم تحریرت رو از
            <Link className="Link m-1" href="#">
              <b>اینجا</b>
            </Link>
            بخر
          </span>
          <div className="Z" d-none="true" d-md-flex="true">
            <Link
              className="Link"
              href="#"
              style={{ gap: "10px", display: "flex", alignItems: "center" }}
            >
              <BsChevronLeft />
              برای خرید کلیک کنید
            </Link>
            <div></div>
          </div>
        </div>

        <div className="X ">
          {db.JA.map((item) => (
            <Link
              key={item.id}
              href="#"
              style={{ borderRadius: "30px", position: "relative" }}
            >
              <Image
                id={item.id}
                src={item.picture}
                alt={item.id}
                width={900}
                height={900}
                onLoad={() => setIsLoading(false)}
              />
              {isLoading && <Skeleton />}
            </Link>
          ))}
        </div>
      </div>

      <div className="JJ">
        <span>
          <b>دسته بندی محصولات اینجا</b>
        </span>
      </div>

      <Pushak />

      <div className="RR">
        <Link className="SS " href="#">
          <Image
            src="/images/11.gif"
            alt="11"
            width={900}
            height={900}
            onLoad={() => setIsLoading(false)}
            unoptimized={true}
          />
          {isLoading && <Skeleton />}
        </Link>
        <Link className="TT " href="#">
          <Image
            src="/images/12.webp"
            alt="12"
            width={900}
            height={900}
            onLoad={() => setIsLoading(false)}
          />
          {isLoading && <Skeleton />}
        </Link>
      </div>

      <div className="UU">
        <span>
          <b>انتخاب کن اینجا</b>
        </span>
      </div>

      <Slids />

      <div className="YY">
        <span>
          <b> درباره </b>
        </span>
        <span className="P">
          <b>اینجا</b>
        </span>
      </div>
      <Section />
    </>
  );
}

export default HomeComponent;

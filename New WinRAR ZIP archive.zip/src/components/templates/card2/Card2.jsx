"use client"
import React from "react";
import styles from "./card2.module.scss";
import { faCalendar } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import "swiper/css/pagination";
import Link from "next/link";
import Image from "next/image";
import db from "../../../../data/db.json";
import { useState } from "react";
import Skeleton from "@/components/modules/skeleton/Skeleton";

function Card() {
  const [isLoading, setIsLoading] = useState(true);

  return (
    <>
      <div className={styles.KK}>
        <Swiper
          slidesPerView={5}
          centeredSlides={false}
          spaceBetween={20}
          grabCursor={true}
          pagination={{
            clickable: true,
          }}
          className={`${styles.mySwiper} d-none  d-xxl-flex`}
        >
          {db.Aa.map((item) => (
            <SwiperSlide key={item.id} className={styles.Kk}>
              {/* Add a key prop here */}
              <Link className={styles.card} href="#">
                <Image
                  src={item.Picture}
                  className="card-img-top"
                  alt="..."
                  width={900}
                  height={900}
                  onLoad={() => setIsLoading(false)}
                />
                {isLoading && <Skeleton />}
                <div
                  id={item.id}
                  className={styles.cardbody}
                  style={{ color: item.color, backgroundColor: item.colorr }}
                >
                  <ul className={`${styles.cardtitle} text-uppercase`}>
                    {item.title}
                  </ul>
                  <li className={styles.cardtext}>{item.description}</li>
                  <div className={styles.taghvim}>
                    <b>سفارش خود را رزرو کنید</b>
                    <div>
                      <FontAwesomeIcon icon={faCalendar} />
                    </div>
                  </div>

                  {item.isAvailable ? (
                    <div className={`${styles.gheymat} `}>
                      <div className={styles.liner}>
                        <div className={styles.takhfif}>{item.takhfif}</div>
                        <div className={styles.textdecorationlinethrough}>
                          {item.price}
                        </div>
                      </div>
                      <div className={styles.toman}>
                        <span>تومان</span>
                        {item.discount}
                      </div>
                    </div>
                  ) : (
                    <span className={styles.namojud}>ناموجود</span>
                  )}
                </div>
              </Link>
            </SwiperSlide>
          ))}
        </Swiper>
        <Swiper
          slidesPerView={3}
          centeredSlides={false}
          spaceBetween={10}
          grabCursor={true}
          pagination={{
            clickable: true,
          }}
          className={`${styles.mySwiper} d-none d-lg-flex d-xxl-none`}
        >
          {db.Aa.map((item) => (
            <SwiperSlide
              key={item.id}
              className={styles.Kk}
              style={{ width: "30%" }}
            >
              {/* Add a key prop here */}
              <Link className={styles.card} href="#">
                <Image
                  src={item.Picture}
                  className="card-img-top"
                  alt="..."
                  width={900}
                  height={900}
                  onLoad={() => setIsLoading(false)}
                />
                {isLoading && <Skeleton />}
                <div
                  id={item.id}
                  className={styles.cardbody}
                  style={{ color: item.color, backgroundColor: item.colorr }}
                >
                  <ul className={`${styles.cardtitle} text-uppercase`}>
                    {item.title}
                  </ul>
                  <li className={styles.cardtext}>{item.description}</li>
                  <div className={styles.taghvim}>
                    <b>سفارش خود را رزرو کنید</b>
                    <div>
                      <FontAwesomeIcon icon={faCalendar} />
                    </div>
                  </div>

                  {item.isAvailable ? (
                    <div className={`${styles.gheymat} mb-2`}>
                      <div className={styles.liner}>
                        <div className={styles.takhfif}>{item.takhfif}</div>
                        <div className={styles.textdecorationlinethrough}>
                          {item.price}
                        </div>
                      </div>
                      <div className={styles.toman}>
                        <span>تومان</span>
                        {item.discount}
                      </div>
                    </div>
                  ) : (
                    <span className={styles.namojud}>ناموجود</span>
                  )}
                </div>
              </Link>
            </SwiperSlide>
          ))}
        </Swiper>
        <Swiper
          slidesPerView={2}
          centeredSlides={false}
          spaceBetween={10}
          grabCursor={true}
          pagination={{
            clickable: true,
          }}
          className={`${styles.mySwiper} d-none d-sm-flex d-lg-none`}
        >
          {db.Aa.map((item) => (
            <SwiperSlide
              key={item.id}
              className={styles.Kk}
              style={{ width: "40%" }}
            >
              {/* Add a key prop here */}
              <Link className={styles.card} href="#">
                <Image
                  src={item.Picture}
                  className="card-img-top"
                  alt="..."
                  width={900}
                  height={900}
                  onLoad={() => setIsLoading(false)}
                />
                {isLoading && <Skeleton />}
                <div
                  id={item.id}
                  className={styles.cardbody}
                  style={{ color: item.color, backgroundColor: item.colorr }}
                >
                  <ul className={`${styles.cardtitle} text-uppercase`}>
                    {item.title}
                  </ul>
                  <li className={styles.cardtext}>{item.description}</li>
                  <div className={styles.taghvim}>
                    <b>سفارش خود را رزرو کنید</b>
                    <div>
                      <FontAwesomeIcon icon={faCalendar} />
                    </div>
                  </div>

                  {item.isAvailable ? (
                    <div className={`${styles.gheymat} mb-2`}>
                      <div className={styles.liner}>
                        <div className={styles.takhfif}>{item.takhfif}</div>
                        <div className={styles.textdecorationlinethrough}>
                          {item.price}
                        </div>
                      </div>
                      <div className={styles.toman}>
                        <span>تومان</span>
                        {item.discount}
                      </div>
                    </div>
                  ) : (
                    <span className={styles.namojud}>ناموجود</span>
                  )}
                </div>
              </Link>
            </SwiperSlide>
          ))}
        </Swiper>
        <Swiper
          slidesPerView={1}
          centeredSlides={false}
          spaceBetween={10}
          grabCursor={true}
          pagination={{
            clickable: true,
          }}
          className={`${styles.mySwiper} d-sm-none`}
          style={{ paddingLeft: "30%" }}
        >
          {db.Aa.map((item) => (
            <SwiperSlide
              key={item.id}
              className={styles.Kk}
              style={{ width: "80%" }}
            >
              {/* Add a key prop here */}
              <Link className={styles.card} href="#">
                <Image
                  src={item.Picture}
                  className="card-img-top"
                  alt="..."
                  width={900}
                  height={900}
                  onLoad={() => setIsLoading(false)}
                />
                {isLoading && <Skeleton />}
                <div
                  id={item.id}
                  className={styles.cardbody}
                  style={{ color: item.color, backgroundColor: item.colorr }}
                >
                  <ul className={`${styles.cardtitle} text-uppercase`}>
                    {item.title}
                  </ul>
                  <li className={styles.cardtext}>{item.description}</li>
                  <div className={styles.taghvim}>
                    <b>سفارش خود را رزرو کنید</b>
                    <div>
                      <FontAwesomeIcon icon={faCalendar} />
                    </div>
                  </div>

                  {item.isAvailable ? (
                    <div className={`${styles.gheymat} mb-4`}>
                      <div className={styles.liner}>
                        <div className={styles.takhfif}>{item.takhfif}</div>
                        <div className={styles.textdecorationlinethrough}>
                          {item.price}
                        </div>
                      </div>
                      <div className={styles.toman}>
                        <span>تومان</span>
                        {item.discount}
                      </div>
                    </div>
                  ) : (
                    <span className={styles.namojud}>ناموجود</span>
                  )}
                </div>
              </Link>
            </SwiperSlide>
          ))}
        </Swiper>
      </div>
    </>
  );
}

export default Card;

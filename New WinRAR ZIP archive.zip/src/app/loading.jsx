import React from "react";

function Loading() {
  return (
    <>
    <div
      style={{
        width: "100%",
        height: "100dvh",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      <div className="spinner-border" role="status"></div>
    </div>
    </>
  );
}

export default Loading;

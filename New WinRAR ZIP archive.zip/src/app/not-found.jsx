import styles from "@/styles/404.module.scss";
import Link from "next/link";

const page = () => {
  return (
    <>
    <div className={styles.contents}>
      not found 404
      <Link href="/">برگشت به صفحه اصلی</Link>
    </div>
    </>
  );
};

export default page;

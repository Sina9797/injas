import Home from "@/components/templates/home/Home";



function Page() {
  return (
    <>
      <Home />
    </>
  );
}

export default Page;

"use client";

import React, { useEffect, useState } from "react";
import styles from "../../styles/dastebandi.module.scss";
import db from "../../../data/db.json";
import { BsChevronLeft } from "react-icons/bs";
import Link from "next/link";
import { BsSearch } from "react-icons/bs";  
function Dastebandi() {
  const [activeSlide, setActiveSlide] = useState(0);

  // Function to check if the screen is small and redirect
  const checkScreenSizeAndRedirect = () => {
    if (window.innerWidth > 992) {
      window.location.href = "./"; // Redirecting to homepage
    }
  };

  useEffect(() => {
    checkScreenSizeAndRedirect(); // Initial check on mount
    window.addEventListener("resize", checkScreenSizeAndRedirect); // Check on window resize

    return () => window.removeEventListener("resize", checkScreenSizeAndRedirect); // Cleanup listener
  }, []);

  // Check if there are slides available
  const hasSlides = db.slides && db.slides.length > 0;

  useEffect(() => {
    console.log("Active slide index:", activeSlide); // Log the active slide index
  }, [activeSlide]);

  return (
    <>
    <div className={styles.DAD}>
      <div style={{ direction: "rtl" }}>
        <div className={styles.megas}>
          <div className={styles.headers}>
            {hasSlides && db.slides.map((slide, index) => (
              <button
                key={index}
                onMouseOver={() => setActiveSlide(index)}
                onFocus={() => setActiveSlide(index)} // Also set active on focus for better accessibility
                className={activeSlide === index ? styles.activeTitle : ""} // Apply activeTitle class based on activeSlide
                aria-label={`Slide ${slide.title}`} // Accessibility enhancement
                
              >
                <span>{slide.title}</span>
              </button>
            ))}
          </div>

          {hasSlides && (
            <div className={styles.contents}>
             <Link 
             
                 href={`/shop?logoo=${db.slides[activeSlide]?.title}`}
                    style={{  
                      fontSize: "12px",  
                      display: "flex",  
                      gap: "5px",  
                      alignItems: "center",  
                      color: "rgb(27, 170, 189)",  
                      textDecoration:"none"
                    }}  
                  > 
                    همه محصولات {db.slides[activeSlide]?.title}  
                    <BsSearch style={{fontSize:"12px"}} />  
                  
                  </Link> 
              <ul>
             {db.slides[activeSlide]?.items?.map((item, index) => (
                  <li key={index}>
                    <span
                      style={{
                        display: "flex",
                        alignItems: "center",
                        gap: "5px",
                      }}
                    >
                      <span style={{ color: "red" }}>|</span> {item.name}
                       <BsChevronLeft style={{fontSize:"12px"}}  /> 
                    </span>
                    <ul
                      style={{
                        display: "flex",
                        flexDirection: "column",
                        gap: "0",
                        color: "gray",
                      }}
                    >
                      {item.details?.map((detail, detailIndex) => (
                          <li key={detailIndex}><Link style={{textDecoration:"none"}} href={`/shop?logo=${detail}`}>{detail}</Link></li>  
                      ))}
                    </ul>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </div>
    </div>
    </>
  );
}

export default Dastebandi;

"use client";

import React, { useRef, useEffect } from "react";
import styles from "@/styles/vorud.module.scss";
import Link from "next/link";
import { Button } from "@heroui/react";
function Vorud() {
  const inputRef = useRef(null);

  useEffect(() => {
    if (inputRef.current) {
      inputRef.current.focus();
    }
  }, []);

  return (
    <>
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "80dvh",
        }}
      >
        <div className={styles.Vorudi}>
          <h1>اینجا</h1>
          <div
            style={{ display: "flex", flexDirection: "column", gap: "20px" }}
          >
            <div style={{ display: "flex", gap: "5px", fontSize: "14px" }}>
              <span>ورود</span>
              <span>|</span>
              <span>ثبت نام</span>
            </div>
            <span style={{ display: "flex", flexDirection: "column" }}>
              <span style={{ fontSize: "12px" }}>سلام!</span>
              <span style={{ fontSize: "12px" }}>
                لطفا شماره موبایل یا ایمیل خود را وارد کنید
              </span>
            </span>
            <input
              type="text"
              className={styles.input}
              style={{ backgroundColor: "#c0c0c036" }}
              ref={inputRef}
            />
            <Button
              className={styles.btn}
              style={{ backgroundColor: "red", color: "white" }}
            >
              ورود
            </Button>
            <span style={{ fontSize: "12px",display:"flex",gap:"5px" }}>
              ورود شما به معنای پذیرش
              <Link href="/" style={{ color: "blue",textDecoration:"none" }}>
                 شرایط اینجا
              </Link>
              و
              <Link href="/" style={{ color: "blue",textDecoration:"none" }}>
                 قوانین حریم خصوصی
              </Link>
              است
            </span>
          </div>
        </div>
      </div>
    </>
  );
}

export default Vorud;

import React from "react";
import styles from "@/styles/sabad.module.scss";
import Image from "next/image";

function Page() {
  return (
    <>
    <div
      style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        height: "70dvh",
      }}
    >
      <div className={styles.Sabad}>
        <Image
          src="/images/Sabad.png"
          style={{ width: "70%", height: "70%" }}
          width={900}
          height={900}
          alt="salam"
        />
        <span style={{ fontSize: "20px" }}>سبد خرید شما خالی است!</span>
        <span style={{ fontSize: "11px", color: "gray" }}>
          می‌توانید برای مشاهده محصولات بیشتر به صفحه اصلی بروید:
        </span>
      </div>
    </div>
    </>
  );
}

export default Page;

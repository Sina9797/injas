import { Geist, Geist_Mono } from "next/font/google";
import "./globals.scss";
import Header from "@/components/templates/header/Header";
import Footer from "@/components/templates/footer/Footer";
import "bootstrap/dist/css/bootstrap.min.css";
import { Suspense } from "react";
import Loading from "./loading";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata = {
  title: "فروشگاه اینترنتی اینجا",
  icons: {
    icon: "/images/inja.png",
  },
  openGraph: {
    title: "فروشگاه اینترنتی اینجا",
    description: "فروشگاه اینترنتی اینجا",
    url: "https://projectt-liard.vercel.app/",
    metadataBase: new URL("https://projectt-liard.vercel.app/"),
    siteName: "فروشگاه اینترنتی اینجا",
    creator: "فروشگاه اینترنتی اینجا",
    images: [
      {
        url: "https://techrasa.com/wp-content/uploads/2016/09/online-shopping.jpg",
        width: 800,
        height: 600,
      },
    ],
    locale: "fa_IR",
    type: "website",
  },
};

export default function RootLayout({ children }) {
  return (
    <html lang="fa">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        <Suspense
          fallback={
            <div>
              <Loading />
            </div>
          }
        >
          <Header />
          {children}
          <Footer />
        </Suspense>
      </body>
    </html>
  );
}

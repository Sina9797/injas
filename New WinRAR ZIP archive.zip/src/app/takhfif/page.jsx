import React from "react";
import Image from "next/image";

function Page() {
  return (
    <>
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          padding: "20px",
        }}
      >
        <Image
          src="/images/loading.jpg"
          style={{ width: "100dvh", height: "50%dvh" }}
          width={900}
          height={900}
          alt="Image"
        />
        <span style={{ display: "flex", direction: "rtl", fontSize: "20px" }}>
          در دست راه اندازی ...
        </span>
      </div>
    </>
  );
}

export default Page;

"use client";
import React, { useState, useEffect } from "react";
import { BsShop, BsStars, BsChevronLeft, BsShieldCheck, BsTruck, BsWatch, BsExclamationCircle } from "react-icons/bs";
import { FaStar } from "react-icons/fa";
import { Button } from "@heroui/react";
import Tooltip from "@/components/modules/tooltip/Tooltip";
import db from "@/../../data/db.json";
import Link from 'next/link';
import { Swiper, SwiperSlide } from 'swiper/react';
import 'swiper/css';
import 'swiper/css/free-mode';
import 'swiper/css/thumbs';
import { FreeMode, Thumbs } from 'swiper/modules';
import Image from "next/image";

function Page({ params }) {
    const [thumbsSwiper, setThumbsSwiper] = useState(null);
    const [unwrappedParams, setUnwrappedParams] = useState(null);
    const [isLoading, setIsLoading] = useState(true);

    // Unwrap the params
    useEffect(() => {
        const fetchParams = async () => {
            const result = await params; // Await to get the resolved params object
            setUnwrappedParams(result);
        };
        fetchParams();
    }, [params]);

    // It is safe to reference id after params are unwrapped
    const id = unwrappedParams?.id; // Use optional chaining to handle potential undefined state

    const colors = [
        { id: 1, name: "طلایی", hex: "#D09B00" },
        { id: 2, name: "خاکستری", hex: "#B0B0B0" },
    ];

    const [selectedColor, setSelectedColor] = useState(colors[0]);

    const handleColorClick = (color) => {
        setSelectedColor(color);
    };

    const item = db.caard.find((item) => item.id === Number(id));

    useEffect(() => {
        if (item) {
            setIsLoading(false);
        }
    }, [item]);

    if (isLoading) {
        return (
            <div className="spinner-container">
                <div className="spinner"></div>
            </div>
        );
    }

    if (!item) {
        return <div>Item not found</div>;
    }

    return (
        <>
        <div className="pro">
            <div className="proo">
                <div className="prooo">
                    <Link href="#">
                        فروش در فروشگاه <BsShop />
                    </Link>
                    <div>
                        <Link href="#">گوشی موبایل</Link>
                        <span>/</span>
                        <Link href="#">موبایل</Link>
                        <span>/</span>
                        <Link href="#">فروشگاه</Link>
                    </div>
                </div>

                <div className="product" key={item.id}>
                    <div className="productt">
                        <div className="breadcrumbs">
                            <span>اپل</span>
                            <span>/</span>
                            <span>گوشی موبایل اپل</span>
                        </div>
                        <span style={{ fontSize: "20px" }}>{item.title}</span>
                        <div className="productttt">
                            <div className="producttttt">
                                <p className="seas">
                                    Apple iPhone ZDA Single SIM 256GB And 6GB RAM Mobile Phone - Not Active F-Part Number
                                </p>
                                <div className="star">
                                    <span>
                                        <span className="emtiaz">
                                            <FaStar /> ۳.۶
                                        </span>
                                        <span className="emtiazz">(امتیاز ۳۳ خریدار)</span>
                                    </span>
                                    <span className="starr">
                                        <BsStars />
                                        خلاصه دیدگاه ها
                                    </span>
                                    <span className="starrr">
                                        ۱۰۵ دیدگاه <BsChevronLeft className="svj" />
                                    </span>
                                    <span className="starrrr">
                                        ۸۷ پرسش <BsChevronLeft className="svj" />
                                    </span>
                                </div>
                                <div>
                                    <h5 className="color">{`رنگ: ${selectedColor.name}`}</h5>
                                    <div style={{ display: "flex", gap: "10px" }}>
                                        {colors.map((color) => (
                                            <div
                                                className="colorr"
                                                key={color.id}
                                                onClick={() => handleColorClick(color)}
                                                style={{
                                                    border: selectedColor.id === color.id
                                                        ? "3px solid cyan"
                                                        : "1px solid rgba(192, 192, 192, 0.48)",
                                                }}
                                            >
                                                <div
                                                    className="colorrr"
                                                    style={{
                                                        backgroundColor: color.hex,
                                                    }}
                                                    onMouseEnter={(e) => {
                                                        const popover = e.currentTarget.querySelector(".popover");
                                                        popover.style.visibility = "visible";
                                                        popover.style.backgroundColor = "rgb(33, 1, 85)";
                                                    }}
                                                    onMouseLeave={(e) => {
                                                        const popover = e.currentTarget.querySelector(".popover");
                                                        popover.style.visibility = "hidden";
                                                    }}
                                                >
                                                    {selectedColor.id === color.id && (
                                                        <svg
                                                            xmlns="http://www.w3.org/2000/svg"
                                                            width="24"
                                                            height="24"
                                                            viewBox="0 0 24 24"
                                                            style={{
                                                                position: "absolute",
                                                                color: "white",
                                                                top: "50%",
                                                                left: "50%",
                                                                transform: "translate(-50%, -50%)",
                                                            }}
                                                        >
                                                            <path d="M6 12l4 4L18 8" stroke="white" strokeWidth="2" fill="none" />
                                                        </svg>
                                                    )}
                                                    <div className="popover" style={{ backgroundColor: color.hex }}>
                                                        {color.name}
                                                    </div>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <span className="bime">بیمه</span>
                                <div className="bimeh">
                                    <div className="bimehh">
                                        <div style={{ width: "20px", height: "20px" }}>
                                            <input type="checkbox" />
                                        </div>
                                    </div>
                                    <div className="bimehhh">
                                        <span>بیمه تجهیزات دیجیتال - بیمه سامان</span>
                                        <div>
                                            <ul>
                                                <li>۵۰٪</li>
                                                <li className="bim">۲,۷۳۹,۰۰۰ تومان</li>
                                                <li> ۱,۳۶۹,۵۰۰ تومان</li>
                                            </ul>
                                            <Link href={"#"}>
                                                جزییات
                                                <BsChevronLeft className="svj" />
                                            </Link>
                                        </div>
                                    </div>
                                </div>
                                <span className="vig">ویژگی‌ها</span>
                                <div className="vijegi">
                                    <div>
                                        <span>فناوری صفحه‌ نمایش</span>
                                        <span style={{ color: "black" }}>Super Retina XDR OLED</span>
                                    </div>
                                    <div>
                                        <span>نسخه سیستم عامل</span>
                                        <span>iOS 15</span>
                                    </div>
                                    <div>
                                        <span>رزولوشن دوربین اصلی</span>
                                        <span>12 مگاپیکسل</span>
                                    </div>
                                    <div>
                                        <span>اندازه</span>
                                        <span>6.7</span>
                                    </div>
                                    <div>
                                        <span>اقلام همراه</span>
                                        <span>دفترچه‌ راهنما، کابل Lightning...</span>
                                    </div>
                                </div>
                            </div>
                            <div className="cardd">
                                <div>
                                    <span>فروشنده</span>
                                    <span style={{ color: "rgb(0, 180, 204)" }}>۱ فروشنده دیگر</span>
                                </div>
                                <div className="cardd1">
                                    <img src="/images/digi.png" alt="فروشگاه" />
                                    فروشگاه اینجا
                                </div>
                                <div className="cardd2">
                                    <span>۴۰%</span>
                                    <span>رضایت از کالا</span>
                                    <span>|</span>
                                    <span>عملکرد</span>
                                    <span>عالی</span>
                                </div>
                                <span className="cardd4">{item.discount} تومان</span>
                                <span className="cardd5">🔥 ۱۰۰+ فروش در هفته گذشته</span>
                                <Button className="cardd6">افزودن به سبد</Button>
                                <span className="cardd7">
                                    <BsShieldCheck />
                                    گارانتی ۱۸ ماهه شرکتی
                                </span>
                                <div className="cardd9">
                                    <span>
                                        <BsTruck />
                                        ارسال اینجا
                                    </span>
                                    <span>
                                        <BsChevronLeft />
                                    </span>
                                </div>
                                <span className="cardd10">
                                    <BsWatch />
                                    ارسال امروز (فعلا در شهر تهران و کرج)
                                </span>
                                <span className="cardd12">
                                    <img src="/images/club.svg" alt="دیجی‌کلاب" />
                                    ۱۵۰ امتیاز دیجی‌کلاب
                                    <BsExclamationCircle />
                                </span>
                            </div>
                        </div>
                    </div>
                    <div className="producttt">
                        <div>
                            <Swiper
                                style={{
                                    width: "85%",
                                    paddingBottom: "20px",
                                    height: "55dvh"
                                }}
                                spaceBetween={10}
                                thumbs={{ swiper: thumbsSwiper }}
                                modules={[FreeMode, Thumbs]}
                                className="mySwiper2"
                            >
                                {item.images.map((image) => (
                                    <SwiperSlide key={image}>
                                        <a>
                                            <Image
                                                style={{ width: "100%", height: "100%", borderRadius: "15px" }}
                                                src={image}
                                                onLoad={() => setIsLoading(false)}
                                               width={900}
                                                height={900}
                                                alt=""
                                            />
                                        </a>
                                    </SwiperSlide>
                                ))}
                            </Swiper>
                            <Swiper
                                onSwiper={setThumbsSwiper}
                                spaceBetween={10}
                                slidesPerView={6}
                                freeMode={true}
                                watchSlidesProgress={true}
                                modules={[FreeMode, Thumbs]}
                                className="mySwiper"
                                style={{
                                    width: "80%",
                                }}
                            >
                                {item.images.map((image) => (
                                    <SwiperSlide  key={image} style={{ borderRadius: "15px", border: "1px solid rgba(128, 128, 128, 0.356)", padding: "10px" }}>
                                       
                                            <Image
                                                src={image}
                                                width={900}
                                                height={900}
                                                alt="Image"
                                            />
                                       
                                    </SwiperSlide>
                                ))}
                            </Swiper>
                        </div>
                        <Tooltip />
                    </div>
                </div>
            </div>
        </div>
        </>
    );
}

export default Page;
"use client";
import { BsChevronDown, BsSliders, BsSortDown, BsTruck } from "react-icons/bs";
import React, { useState, useEffect } from "react";
import Skeletonn from "@/components/modules/skeletonn/Skeletonn";
import { useSearchParams } from "next/navigation";
import Link from "next/link";
import { FaStar } from "react-icons/fa";
import Accordions from "@/components/modules/accordions/Accordions";
import db from "../../../data/db.json";
import Image from "next/image";

const Page = () => {
  const [isLoading, setIsLoading] = useState(true);
  const [data, setData] = useState([]);
  const [filteredData, setFilteredData] = useState([]);
  const searchParams = useSearchParams();
  const logoFromUrl = searchParams.get("logo");
  const logooFromUrl = searchParams.get("logoo");
  const searchQuery = searchParams.get("query");

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await Promise.resolve(db);
        setData(response.caard || []);

        let filtered = response.caard;

        // Filter by search query if it exists
        if (searchQuery) {
          filtered = filtered.filter((item) =>
            item.title.toLowerCase().includes(searchQuery.toLowerCase())
          );
        }

        // Filter by logo if logoFromUrl exists
        if (logooFromUrl) {
          filtered = filtered.filter((item) =>
            item.logoo && item.logoo.toLowerCase() === logooFromUrl.toLowerCase()
          );
        }
        
        if (logoFromUrl) {
          filtered = filtered.filter((item) =>
            item.logo && item.logo.toLowerCase() === logoFromUrl.toLowerCase()
          );
        }

        console.log("Filtered Data:", filtered);
        setFilteredData(filtered);
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, [logoFromUrl, logooFromUrl, searchQuery]); // Add searchQuery to dependencies

  const truncateTitle = (title) => {
    if (!title) return "";
    const maxLength = window.matchMedia("(max-width: 35em)").matches ? 55 : 83;
    return title.length > maxLength ? title.slice(0, maxLength) + "..." : title;
  };
  return (
    <>
    <div className="topercard">
      <div className="top">
        <div>
          <Link href="/">فروشگاه اینترنتی اینجا</Link>
          <span>/</span>
          <Link href="/mobile">موبایل</Link>
        </div>
        <span>گوشی موبایل اپل</span>
      </div>
      <div className="toop">
        <div>
          <Link className="filterr" href="/cheapest">
            <BsSortDown style={{ fontSize: "17px" }} />
            ارزان ترین
          </Link>
          <Link className="filterr" href="/filter">
            <BsSliders />
            فیلتر
          </Link>
          <Link className="filterr" href="/color">
            رنگ
            <BsChevronDown />
          </Link>
          <Link className="filterr" href="/tomorrow-delivery">ارسال فردا</Link>
          <Link className="filterr" href="/seller-delivery">ارسال فروشنده</Link>
          <Link className="filterr" href="/price-range">
            محدوده قیمت
            <BsChevronDown />
          </Link>
          <Link className="filterr" href="/available">فقط کالاهای موجود</Link>
          <Link className="filterr" href="/seller-type">
            نوع فروشنده
            <BsChevronDown />
          </Link>
          <Link className="filterr" href="/os">
            سیستم عامل
            <BsChevronDown />
          </Link>
          <Link className="filterr" href="/network">
            شبکه های مخابراتی
            <BsChevronDown />
          </Link>
          <Link className="filterr" href="/sensors">
            حس گرها
            <BsChevronDown />
          </Link>
          <Link className="filterr" href="/sim-type">
            نوع سیم کارت
            <BsChevronDown />
          </Link>
          <Link className="filterr" href="/camera-resolution">
            رزولوشن دوربین اصلی
            <BsChevronDown />
          </Link>
          <Link className="filterr" href="/sim-count">
            تعداد سیم کارت
            <BsChevronDown />
          </Link>
          <Link className="filterr" href="/ram">
            مقدار RAM
            <BsChevronDown />
          </Link>
        </div>
      </div>
      <div className="topcard">
        <div className="main">
          <ul className="filter">
            <li>
             
                <BsSortDown style={{ fontSize: "23px",color:"black" }} />
             
            </li>
            <li style={{ color: "black" }}>مرتب سازی:
             
            </li>
            <li>
              <Link href="/most-viewed">پربازدیدترین</Link>
            </li>
            <li>
              <Link href="/newest">جدیدترین</Link>
            </li>
            <li>
              <Link href="/best-selling">پرفروش ترین</Link>
            </li>
            <li>
              <Link href="/cheapest">ارزان ترین</Link>
            </li>
            <li>
              <Link href="/fastest-delivery">سریع ترین ارسال</Link>
            </li>
            <li>
              <Link href="/buyer-suggestion">پیشنهاد خریداران</Link>
            </li>
            <li>
              <Link href="/selected">منتخب</Link>
            </li>
            <li style={{ position: "absolute", left: "0px" }}>
              {filteredData.length} کالا
            </li>
          </ul>
       

<div className="topcardd">  
  {isLoading ? (  
    Array.from({ length: 10 }).map((_, index) => (  
      <div key={index} className="caard">  
        <Skeletonn />  
      </div>  
    ))  
  ) : filteredData.length === 0 ? ( // Check if there are no filtered products  
    <div style={{ textAlign: 'center', fontSize: '18px', color: 'gray',marginTop:"50px" }}>  
     کالایی یافت نشد! 
    </div>  
  ) : (  
    filteredData.map((item) => (  
      <Link  
      target="blank"
        href={`/shop/${item.id}`}  
        className="caard"  
        key={item.id}  
      >  
        {item.vige ? (  
          <span className="vige">فروش ویژه</span>  
        ) : (  
          <span style={{ visibility: "hidden" }}>.</span>  
        )}  
        <div>  
          <Image src={item.img} alt={item.title} width={900} height={900}/>  
        </div>  

        <div className="details">  
          <span 
            style={{ textAlign: "start", fontSize: "13px" }}  
          >  
            {truncateTitle(item.title)}  
          </span>  
          {item.isAvailable ? (  
            <>  
              <div  
                style={{  
                  display: "flex",  
                  alignItems: "center",  
                  justifyContent: "space-between",  
                }}  
              >  
                <div  
                  style={{  
                    display: "flex",  
                    alignItems: "center",  
                    gap: "5px",  
                  }}  
                >  
                  <FaStar style={{ color: "orange" }} />  
                  {item.emtiaz}  
                </div>  

                <div>  
                  {item.ersal ? (  
                    <div  
                      style={{  
                        display: "flex",  
                        alignItems: "center",  
                        gap: "5px",  
                        fontSize: "11px",  
                        flexDirection: "row",  
                      }}  
                    >  
                      ارسال امروز  
                      <BsTruck  
                        style={{  
                          fontSize: "17px",  
                          marginBottom: "3px",  
                        }}  
                      />  
                    </div>  
                  ) : (  
                    <span style={{ fontSize: "11px", color: "red" }}>  
                      تنها {item.tedad} عدد در انبار باقی مانده  
                    </span>  
                  )}  
                </div>  
              </div>  

              <div  
                style={{  
                  display: "flex",  
                  alignItems: "center",  
                  justifyContent: "space-between",  
                }}  
              >  
                <div  
                  style={{  
                    display: "flex",  
                    flexDirection: "row-reverse",  
                    gap: "3px",  
                  }}  
                >  
                  <span>{item.discount}</span> <span>تومان</span>  
                </div>  
                <span  
                  style={{  
                    backgroundColor: "red",  
                    paddingInline: "12px",  
                    borderRadius: "50rem",  
                    color: "white",  
                  }}  
                >  
                  {item.takhfif}  
                </span>  
              </div>  
            </>  
          ) : (  
            <span style={{ fontSize: "15px" }}>  
              ناموجود  
            </span>  
          )}  
        </div>  
      </Link>  
    ))  
  )}  
</div>
        </div>
        <div className="sidbar">
          <h1 style={{ padding: "20px", fontSize: "20px" }}>فیلترها</h1>
          <div style={{ position: "relative", width: "100%" }}>
            <Accordions />
          </div>
        </div>
      </div>
    </div>
    </>
  );
};

export default Page;